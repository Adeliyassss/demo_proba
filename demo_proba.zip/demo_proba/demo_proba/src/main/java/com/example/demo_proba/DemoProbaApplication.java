package com.example.demo_proba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoProbaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoProbaApplication.class, args);
	}

}
